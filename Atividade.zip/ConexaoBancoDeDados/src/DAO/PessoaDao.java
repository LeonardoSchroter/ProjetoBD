/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Beans.Pessoa;
import conexaobancodedados.Conexao;
import java.awt.List;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author laboratorio
 */
public class PessoaDao {

    private Conexao conexao;
    private Connection conn;

    public PessoaDao() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao("bdaula01");
    }
    
    public void inserir(Pessoa pessoa){
        String sql = "INSERT INTO pessoa (nome,sexo,idioma) VALUES (?,?,?);";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1,pessoa.getNome());
            stmt.setString(2,pessoa.getSexo());
            stmt.setString(3,pessoa.getIdioma());
            
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir pessoa: "+ex.getMessage());
        }
        
    }
    
    
}
